package com.simone.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.simone.entities.Tour;

@Service
public interface ITourService {

	List<Tour> getTours();
}
