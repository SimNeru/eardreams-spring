package com.simone.services;

import org.springframework.stereotype.Service;

import com.simone.entities.Reservation;

@Service
public interface IReservationService{

	Reservation addReservation(Reservation reservation, Long userID, Long tourID);

}
