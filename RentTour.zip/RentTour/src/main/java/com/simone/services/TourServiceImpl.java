package com.simone.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simone.entities.Tour;
import com.simone.repositories.TourDAO;

@Service
public class TourServiceImpl implements ITourService{

	@Autowired
	TourDAO dao;
	
	@Override
	public List<Tour> getTours()
	{
		return dao.findAll();
	}
	

}
