package com.simone.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.simone.entities.User;

@Service
public interface IUserService {
	
	Optional<User> getById(Long id);
	List<User> getUtenti();
	List<User> getByEmail(String email);
	List<User> getByUsername(String username);
	User addUtente(User utenti);

}
