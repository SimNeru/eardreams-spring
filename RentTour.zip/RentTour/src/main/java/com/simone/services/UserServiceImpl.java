package com.simone.services;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService{

}
