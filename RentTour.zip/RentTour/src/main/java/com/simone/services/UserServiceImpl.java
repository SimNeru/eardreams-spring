package com.simone.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simone.entities.User;
import com.simone.repositories.UserDAO;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	UserDAO dao;

	@Override
	public Optional<User> getById(Long id) {
		return dao.findById(id);
	}

	@Override
	public List<User> getUtenti() {
		return dao.findAll();
	}

	@Override
	public List<User> getByEmail(String email) {
		return dao.findByEmail(email);
	}

	@Override
	public List<User> getByUsername(String username) {
		return dao.findByUsername(username);
	}

	@Override
	public User addUtente(User utente) {

		if (dao.findByEmail(utente.getEmail()).isEmpty()) {
			if (dao.findByUsername(utente.getUsername()).isEmpty()) {
				return dao.save(utente);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
}
