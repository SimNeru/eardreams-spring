package com.simone.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simone.entities.Reservation;
import com.simone.entities.Tour;
import com.simone.entities.User;
import com.simone.repositories.ReservationDAO;
import com.simone.repositories.TourDAO;
import com.simone.repositories.UserDAO;

@Service
public class ReservationServiceImpl implements IReservationService{
	
	@Autowired
	UserDAO userDao;
	
	@Autowired
	TourDAO tourDao;

	@Autowired
	ReservationDAO reservationDao;

	@Override
	public Reservation addReservation(Reservation reservation, Long userID, Long tourID) {
		
		Reservation inputReservation = new Reservation();
		inputReservation.setBooking_date(reservation.getBooking_date());
		inputReservation.setUser(userDao.getReferenceById(userID));
		inputReservation.setTour(tourDao.getReferenceById(tourID));
				
		return reservationDao.save(inputReservation);
	}
	
	public void deleteReservation(Long userID, Long tourID) {
		
		Tour tour = tourDao.getReferenceById(tourID);
		User user = userDao.getReferenceById(userID);
		
		List<Reservation> lista = new ArrayList<Reservation>();
		lista = reservationDao.findAll();
		
		for (Reservation reservation : lista) {
			if(reservation.getUser().equals(user) && reservation.getTour().equals(tour)) {
				reservationDao.delete(reservation);
			}
		}
	}
}
