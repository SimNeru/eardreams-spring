package com.simone.entities;

import jakarta.persistence.CascadeType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "reservations")
public class Reservation {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long reservation_id;
	private String booking_date;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "tour_id")
	private Tour tour ;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private User user;

	public Reservation() {
		super();
	}

	public Reservation(int reservation_id, String booking_date, Tour tour, User user) {
		super();
		this.reservation_id = reservation_id;
		this.booking_date = booking_date;
		this.tour = tour;
		this.user = user;
	}

	public long getReservation_id() {
		return reservation_id;
	}

	public void setReservation_id(long reservation_id) {
		this.reservation_id = reservation_id;
	}

	public String getBooking_date() {
		return booking_date;
	}

	public void setBooking_date(String booking_date) {
		this.booking_date = booking_date;
	}

	public Tour getTour() {
		return tour;
	}

	public void setTour(Tour tour) {
		this.tour = tour;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Reservation [reservation_id=" + reservation_id + ", booking_date=" + booking_date + ", tour=" + tour
				+ ", user=" + user + "]";
	}

	
}
