package com.simone.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.FetchType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "tours")
public class Tour {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long tour_id;
	private String name;
	private String type;
	private Integer capacity;
	private Boolean availability;
	private String company;
	private String description;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tour", cascade = CascadeType.ALL)
	private List<Reservation> prenotazioni;

	public Tour() {
		super();
	}

	public Tour(Integer tour_id, String name, String type, Integer capacity, Boolean availability, String company,
			String description, List<Reservation> prenotazioni) {
		super();
		this.tour_id = tour_id;
		this.name = name;
		this.type = type;
		this.capacity = capacity;
		this.availability = availability;
		this.company = company;
		this.description = description;
		this.prenotazioni = prenotazioni;
	}

	public long getTour_id() {
		return tour_id;
	}

	public void setTour_id(long tour_id) {
		this.tour_id = tour_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Boolean getAvailability() {
		return availability;
	}

	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Reservation> getPrenotazioni() {
		return prenotazioni;
	}

	public void setPrenotazioni(List<Reservation> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}
	
	
}
