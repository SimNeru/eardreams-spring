package com.simone.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.simone.entities.Reservation;
import com.simone.services.IReservationService;

@RestController
@RequestMapping("reservations")
public class ReservationControllerREST {

		@Autowired
		IReservationService service;
		
		@PostMapping("add")
		@ResponseBody
		Reservation registerUtente(
				@RequestBody Reservation reservation, 
				@RequestParam Long userID, 
				@RequestParam Long tourID) 
		{ return service.addReservation(reservation, userID, tourID); }
}
