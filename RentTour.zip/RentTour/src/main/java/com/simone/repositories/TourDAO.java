package com.simone.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.simone.entities.Tour;

@Repository
public interface TourDAO extends JpaRepository<Tour, Long> {
	
	Optional<Tour> findById(Long id);
	
//	@Query("select `name` from tours t where t.name like '%?%'")
//	List<Tour> getLikeByName(String name);
//	
//	@Query("select `type` from tours t where t.type like '%?%'")
//	List<Tour> getLikeByTipo(String type);
	

}
