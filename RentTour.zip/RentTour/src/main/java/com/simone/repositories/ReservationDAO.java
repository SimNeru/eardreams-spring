package com.simone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.simone.entities.Reservation;

@Repository
public interface ReservationDAO extends JpaRepository<Reservation, Long>{

}
