package com.simone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentTourApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentTourApplication.class, args);
	}

}
